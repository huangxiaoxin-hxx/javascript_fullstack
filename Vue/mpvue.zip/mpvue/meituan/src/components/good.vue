<template>
  <div class="good">
    <dl class="ub-box ub-wrap z-margin-top-6-px z-padding-v-5-px" style="background:#fff">
      <dd
        @click.stop="$openWin('/pages/error/main')"
        class="adv ub-flex-1 z-box-sizing-border ub-box ub-ver ub-col"
      >
        <span class="z-font-size-14 z-lineHeight-36" style="color:#55a40f">我们约吧</span>
        <span class="z-font-size-12 z-color-666">恋人家人好朋友</span>
        <img class="z-img-cover" src="/static/images/index1.png" />
      </dd>
      <dd
        @click.stop="$openWin('/pages/error/main')"
        class="adv ub-flex-1 z-box-sizing-border z-padding-v-5-px ub-box ub-ver ub-col"
      >
        <span class="z-font-size-14 z-lineHeight-36" style="color:#ff3f0d">低价超值</span>
        <span class="z-font-size-12 z-color-666">十元惠生活</span>
        <img class="z-img-cover" src="/static/images/index2.png" />
      </dd>
      <dd
        @click.stop="$openWin('/pages/error/main')"
        class="adv ub-flex-1 z-box-sizing-border z-padding-v-5-px ub-box ub-ver ub-col"
      >
        <span class="z-font-size-14 z-lineHeight-36" style="color:#f742a0">午后时光</span>
        <span class="z-font-size-12 z-color-666">懒懒下午茶</span>
        <img class="z-img-cover" src="/static/images/index3.png" />
      </dd>
    </dl>
  </div>
</template>

<script>
export default {};
</script>

<style>
</style>